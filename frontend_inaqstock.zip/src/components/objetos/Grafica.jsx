 

export default function Grafica(hola) {
 

  return (
    <div className="text-foreground bg-background min-h-screen">
    <p>{hola}</p>
    </div>
  );
}
